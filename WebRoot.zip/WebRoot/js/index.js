jQuery(function($){
	//��ҳ����			
	$(".cat_tab .label li").click(function(){						   
			$(".cat_tab .label li .left_sel").removeClass("left_sel").addClass("left_def");
			$(".cat_tab .label li .middle_sel").removeClass("middle_sel").addClass("middle_def");
			$(".cat_tab .label li .right_sel").removeClass("right_sel").addClass("right_def");	
			$(this).find(".left").removeClass("left_def").addClass("left_sel");		
			$(this).find(".middle").removeClass("middle_def").addClass("middle_sel");	
			$(this).find(".right").removeClass("right_def").addClass("right_sel");
			$(".cat_tab .content li").hide();
			$(".cat_tab .content li").eq($(this).index()).show();
	});
	
	
	//�б�ҳ�����ʼ��
	var selCat=$("#cat"+$("#cid").html()).parents(".cat");
	selCat.find(".level2").show();
	selCat.find(".levelswitch").removeClass("open").addClass("close");
	
	
	//�б�ҳ���࿪��
	$(".levelswitch").click(function(){
			if($(this).attr("class").indexOf("open")>0){
				$(this).removeClass("open").addClass("close");
				$(this).parent().parent().find(".level2").show();
			}else{
				$(this).removeClass("close").addClass("open");
				$(this).parent().parent().find(".level2").hide();
			}
	});			
				
				
	//����			
	var star=-1;
	$(".grade").children().hover(
	   function(){
	       var star_list=$(this).parent().children();
		   for(var i=0;i<star_list.length;i++){
			   if(i<=$(this).index()){
			     star_list.eq(i).removeClass("grade-star2");
		         star_list.eq(i).addClass("grade-star1");
			   }else{
				   star_list.eq(i).removeClass("grade-star1");
		           star_list.eq(i).addClass("grade-star2");
			   }
		   }
	   },function(){
	       var star_list=$(this).parent().children();
		   for(var i=0;i<star_list.length;i++){
			   if(i<=star){
			     star_list.eq(i).removeClass("grade-star2");
		         star_list.eq(i).addClass("grade-star1");
			   }else{
				   star_list.eq(i).removeClass("grade-star1");
		           star_list.eq(i).addClass("grade-star2");
			   }
		   }
	   }
    ).click(
	   function(){
		   star=$(this).index();
	   }
    );
	
/*	
	$("#comment_submit").click(
		function(){
		   var Grade=star+1;
		   var comment=$("#comment_content").val();
	       if(Grade<=0)alert("����������~~");
		   else if(comment==comment_content_init||comment=="")alert("����д��ʲô��~~");
		   else{
			   if(comment.length<4)alert("��������ϧ������أ�O(��_��)O~");
			   $("#comment_content").val("������...");
			   $.getJSON("/webjson/Comment?time="+timestamp, {
				  aid :Aid,grade:Grade,content :comment
			   }, function(data) {
				   if(data.feedback>0){
					   var comment_item_template=$("#comment_item_template").clone();
					   comment_item_template.hide();
					   comment_item_template.find(".comment_user").html($("#username").html());
					   comment_item_template.find(".comment_content").html(comment);
					   comment_item_template.find(".comment_time").html("�ո�");
					   var starHTML="";
					   for(var i=0;i<Grade;i++){
						   starHTML+="<span class='app_star_icon1'></span>";
					   }
					   for(var i=0;i<5-Grade;i++){
						   starHTML+="<span class='app_star_icon2'></span>";
					   }
					   comment_item_template.find(".comment_star").html(starHTML);
					   comment_item_template.prependTo($(".comment_list"));
					   comment_item_template.fadeIn();
					   
					   //���
					   star=-1;
					   $("#comment_content").val("");
					   $(".app_star").children().removeClass("app_grade_icon1");
					   $(".app_star").children().addClass("app_grade_icon2");
				   }
				   else if(data.feedback==-101){
					   $("#comment_content").val(comment);
					   alert("����û�е�¼Ŷ��");
					   $.colorbox({href:"/user/login.jsp",iframe:true,width:"600", height:'440', title:'�û���¼',opacity:0.3});
				   }
				   else if(data.feedback==-5){
					   $("#comment_content").val(comment);
					   alert("�Բ������Ѿ��ύ�����ˣ�ÿ��Ӧ����ֻ������һ��Ŷ~");
				   }
				   else if(data.feedback==-6){
					   $("#comment_content").val(comment);
					   alert("�Բ��������˻���δ����뼤���˻�������Ŷ~");
				   }
				   else{
					   $("#comment_content").val(comment);
					   alert("�������ڲ�����:"+data.feedback);
				   }
			   });
		   }
		}					  
	);
*/	

});