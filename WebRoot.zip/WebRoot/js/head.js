jQuery(function($){
	$("input[name=smsphone]").focus(function(){
		if($(this).val()=="手机号码"){$(this).val("");}
		$(this).addClass("active");
	}).blur(function(){
		if($(this).val()==""){$(this).val("手机号码");$(this).removeClass("active");}
	});	
	$(".password").focus(function(){
		$(this).hide();						  
		$("#password").show().focus();
	});
	$("input[name=password]").blur(function(){if($(this).val()==""){$(this).hide();$(".password").show();}});
	
	$("#search-btn").click(function(){Search();});
	$("input[name=keyword]").keydown(function(e){
		if(e.keyCode==13)Search();
	});
	function Search(){
		var keyword=$("input[name=keyword]").val();							
		if(keyword=="")alert("输入关键字，有助于我们的查询~");
		else{
			location.href="list?search="+keyword;
		}
	}
	$(".login-btn").click(function(){
		var smsphone=$("input[name=smsphone]").val();
		var password=$("input[name=password]").val();
		if(smsphone==""||smsphone=="手机号码")alert("请输入手机号码");
		else if(password=="")alert("请输入10086密码");
		else location.href="login?smsphone="+smsphone+"&password="+password;
	});		
});