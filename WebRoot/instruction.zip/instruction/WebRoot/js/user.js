jQuery(function($){
	function overallFeedbackHandle(feedback){
		if(feedback==-201)alert("您还没有登录哦~");
	}
	$("#cat").change(function(){
		var cat=$(this).children('option:selected').val();
		var strs= new Array();
        strs=cat.split("|"); 
		var cid=strs[0];
		if($("#bid")!=null){
			$("#bid").html("");
			$.getJSON("/json/brandsByCid?time="+new Date().getTime()/1000, {"cid" :cid}, function(data) {
					 overallFeedbackHandle(data.feedback);
					 jQuery.each(data.brands,function(index,brand){
							$("#bid").append("<option value='"+brand.id+"'>"+brand.name+"</option>");
					 });
							$("#bid").append("<option value='-12345'>其他</option>");
			 });
		}
    });
				
	$('#imgBtn').uploadify({   
 		'uploader': '/css/images/uploadify.swf',
        'script': '/json/uploadFile;jsessionid='+JSESSIONID,   //指定服务端处理类的入口
        'folder': 'avatar',   
 		'cancelImg': '/css/images/cancel.png',
        'fileDataName': 'file', //和input的name属性值保持一致就好，Struts2就能处理了   
        'queueID': 'fileQueue1',   
        'auto': true,//是否选取文件后自动上传   
        'multi': false,//是否支持多文件上传
        'simUploadLimit' : 1,//每次最大上传文件数   
        'buttonText': '上传图片',//按钮上的文字
		'fileExt':'*.jpg;*.gif;*.png;*.bmp;', 
		'fileDesc':'请上传图片，支持JPG,PNG,GIF,BMP',    
        'displayData': 'percentage',//有speed和percentage两种，一个显示速度，一个显示完成百分比    
        'onComplete': function (event, queueID, fileObj, res, _data){
		    data=JSON.parse(res);
			overallFeedbackHandle(data.feedback);
			if(data.feedback==100){
				$("#iconUrl").val(data.fileFolderAndName);
				$("#imgshow").html("<img src='/uploadfileTemp/"+data.fileFolderAndName+"'  width='240px'/>");
			}else alert(data.feedback);
        },
		'onError' : function(event, queueID, fileObj,errorObj){
			alert("Error");
		    //alert(errorObj.type + "Error:" + errorObj.info);
		}
	});	
		
	$('#fileBtn').uploadify({   
 		'uploader': '/css/images/uploadify.swf',
        'script': '/json/uploadFile;jsessionid='+JSESSIONID,   //指定服务端处理类的入口
        'folder': 'avatar',   
 		'cancelImg': '/css/images/cancel.png',
        'fileDataName': 'file', //和input的name属性值保持一致就好，Struts2就能处理了   
        'queueID': 'fileQueue2',   
        'auto': true,//是否选取文件后自动上传   
        'multi': false,//是否支持多文件上传
        'simUploadLimit' : 1,//每次最大上传文件数   
        'buttonText': '上传文件',//按钮上的文字   
		'fileExt':'*.pdf;*.doc;*.ppt;*.docx;*.pptx', 
		'fileDesc':'请上传PDF或者office文件', 
        'displayData': 'percentage',//有speed和percentage两种，一个显示速度，一个显示完成百分比    
        'onComplete': function (event, queueID, fileObj, res, _data){ 
		    data=JSON.parse(res);
			overallFeedbackHandle(data.feedback);
			if(data.feedback==100){
				$("#fileUrl").val(data.fileFolderAndName);
			}
        },
		'onError' : function(event, queueID, fileObj,errorObj){
			alert("Error");
		    //alert(errorObj.type + "Error:" + errorObj.info);
		}
	});	
	
	var description_content_init="/请添加产品简单说明/";
	$("#description").focus(function(){
		if($(this).val()==description_content_init){
			   $(this).val("");
			   $(this).css("color","#000");
		}
    }).blur(
	   function(){
		   if($(this).val()==""){
			   $(this).val(description_content_init);
			   $(this).css("color","#ccc");
		   }
	   }						
	);
	
	
	$("#sub").click(function(){
		var cat=$("#cat").children('option:selected').val();
		var strs= new Array();
        strs=cat.split("|"); 
		var cid=strs[0];
		var cat_level=strs[1];
		var bid=$("#bid").val();
		var model=$("#model").val();
		var title=$("#title").val();
		var description=$("#description").val();
		var iconUrl=$("#iconUrl").val();
		var fileUrl=$("#fileUrl").val();
		var status=0;
		if($("input[name=status]").attr('checked')!=undefined)status=1;
		
		var verify=true;
		if(cid==""||cid==0){
			$("#cid-notification").addClass("error").html("请选择分类");verify=false;
		}else {
			$("#cid-notification").html("").removeClass("error").addClass("success");
		}
		if(cat_level==0){
		    $("#cid-notification").addClass("error").html("请选择二级及以下分类");verify=false;
		}
		else {
			$("#cid-notification").html("").removeClass("error").addClass("success");
		}
		if(bid==""||bid==0){
			$("#bid-notification").addClass("error").html("请选择品牌");verify=false;
		}else {
			$("#bid-notification").html("").removeClass("error").addClass("success");
		}
		if(model==""){
			$("#model-notification").addClass("error").html("请输入型号");verify=false;
		}else {
			$("#model-notification").html("").removeClass("error").addClass("success");
		}
		if(title==""){
			$("#title-notification").addClass("error").html("请输入标题");verify=false;
		}else {
			$("#title-notification").html("").removeClass("error").addClass("success");
		}
		if(iconUrl==""){
			$("#iconUrl-notification").addClass("error").html("请上传图片");verify=false;
		}else {
			$("#iconUrl-notification").html("").removeClass("error").addClass("success");
		}
		if(fileUrl==""){
			$("#fileUrl-notification").addClass("error").html("请上传文件");verify=false;
		}else {
			$("#fileUrl-notification").html("").removeClass("error").addClass("success");
		}
		
		if(verify){
			var param={"insUpload.cid":cid,"insUpload.bid":bid,"insUpload.model":model,"insUpload.title":title,"insUpload.description":description,"insUpload.iconUrl":iconUrl,"insUpload.fileUrl":fileUrl,"status":status};
			$.getJSON("/json/upload?time="+new Date().getTime()/1000,param, function(data) {
			     overallFeedbackHandle(data.feedback);
				 if(data.feedback==100){
					 alert("上传成功,正在等待审核，通过后将给您增加来福币，谢谢您的支持~");
					 location.href="/listInsOfUser";
				 }
				 else{
			         //alert("上传失败，错误编号:"+data.feedback);
					 if(data.feedback==-602){
						 $("#title-notification").addClass("error").html("标题已存在");
						 alert("标题已存在");
					 }
				 }
	        });
		}else{
		}
	});
	
	
	$("#cat,#bid,#model").change(function(){
	   var title=($("#bid").find("option:selected").text()).replace(/\s+/g,"")+$("#model").val()+($("#cat").find("option:selected").text()).replace(/\s+/g,"")+"说明书下载";
	   $("#title").val(title);
	   $("#title").val($("#title").val().replace(/\s+/g,""));
	});
	
	$('tbody tr:even').addClass("alt-row");
	
	
});