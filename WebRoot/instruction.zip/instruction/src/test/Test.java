package test;

import java.io.UnsupportedEncodingException;
import java.util.LinkedList;
import java.util.Map;

import com.fivestars.interfaces.bbs.client.UCClient;
import com.fivestars.interfaces.bbs.util.XMLHelper;

/**
 * ================================================ Discuz! Ucenter API for JAVA
 * ================================================ 测试类 示例：本类实现在如何实现在登入/登出，以及注册。
 * 
 * 更多信息：http://code.google.com/p/discuz-ucenter-api-for-java/ 作者：梁平
 * (no_ten@163.com) 创建时间：2009-2-20
 */
public class Test {

	/**
	 * @param args
	 * @throws UnsupportedEncodingException
	 */
	public static void main(String[] args) throws UnsupportedEncodingException {

//		 testLogin();
		UCClient uc = new UCClient();
//
		String code = "ac71i9pT09Nagi2rS6/AibE6LCjIIk1WBXPkjJmADo7k1iVLYbyKe0QB06u98i0y1JPB5VNYKCFTbvuKrpanETx2tZ6FVq9lnHKTM8jnWXzTRUidvOMHQJqtLJ+1ZZEi3SrRN3hTu+hXe3ApRGCYar9cJK93SkPh/SLAytdkUbSVWLZ5Yd7WW45dt/vxlXr7rhleYWLgB9PdXODSy+DJcg";
		System.out.println("PHP加密密文:" + code);
		// code= uc.uc_authcode(code, "DECODE");
		Map<String, String> map = uc.decodeReturnMap(code);
		System.out.println("解密:" + map);

//		 String x=uc.uc_user_synlogin(56609);
//		 System.out.println(x);

	}

	public static void testLogin() {

		UCClient e = new UCClient();
		String result = e.uc_user_login("380050803@qq.com", "122422", "");

		LinkedList<String> rs = XMLHelper.uc_unserialize(result);
		System.out.println(rs);
		if (rs.size() > 0) {
			int $uid = Integer.parseInt(rs.get(0));
			String $username = rs.get(1);
			String $password = rs.get(2);
			String $email = rs.get(3);
			if ($uid > 0) {
				System.out.println("登录成功");
				System.out.println($username);
				System.out.println($password);
				System.out.println($email);

				String $ucsynlogin = e.uc_user_synlogin($uid);
				System.out.println("登录成功" + $ucsynlogin);

			} else if ($uid == -1) {
				System.out.println("用户不存在,或者被删除");
			} else if ($uid == -2) {
				System.out.println("密码错");
			} else {
				System.out.println("未定义");
			}
		} else {
			System.out.println("Login failed");
			System.out.println(result);
		}
	}

	public static void testLogout() {

		UCClient uc = new UCClient();

		// setcookie('Example_auth', '', -86400);
		// 生成同步退出的代码
		String $ucsynlogout = uc.uc_user_synlogout();
		System.out.println("退出成功" + $ucsynlogout);

	}

	public static void testRegister() {

		UCClient uc = new UCClient();

		// setcookie('Example_auth', '', -86400);
		// 生成同步退出的代码
		String $returns = uc.uc_user_register("cccc", "ccccc", "ccc@abc.com");
		int $uid = Integer.parseInt($returns);
		if ($uid <= 0) {
			if ($uid == -1) {
				System.out.print("用户名不合法");
			} else if ($uid == -2) {
				System.out.print("包含要允许注册的词语");
			} else if ($uid == -3) {
				System.out.print("用户名已经存在");
			} else if ($uid == -4) {
				System.out.print("Email 格式有误");
			} else if ($uid == -5) {
				System.out.print("Email 不允许注册");
			} else if ($uid == -6) {
				System.out.print("该 Email 已经被注册");
			} else {
				System.out.print("未定义");
			}
		} else {
			System.out.println("OK:" + $returns);
		}

	}

}
