package instruction.model;

public class InsUpload {
	private static final long serialVersionUID = 3254988447778086189L;
	private int id = 0;
	private String model;
	private String title;
	private String description;
	private String iconUrl;
	private String fileUrl;
	private int cid = 0;
	private int bid = 0;
	private String g3Url;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getIconUrl() {
		return iconUrl;
	}

	public void setIconUrl(String iconUrl) {
		this.iconUrl = iconUrl;
	}

	public String getFileUrl() {
		return fileUrl;
	}

	public void setFileUrl(String fileUrl) {
		this.fileUrl = fileUrl;
	}

	public void setBid(int bid) {
		this.bid = bid;
	}

	public int getBid() {
		return bid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public int getCid() {
		return cid;
	}

	public void setG3Url(String g3Url) {
		this.g3Url = g3Url;
	}

	public String getG3Url() {
		return g3Url;
	}
}
