package instruction.service;

import java.util.List;

import instruction.model.Brand;
import instruction.util.page.PageView;

public interface BrandService {
	public PageView<Brand> getByCid(int cid,int pageNum,int pageSize);

	public int add(String name, String nameEn, String nameZh);

	public int edit(int bid, String name, String nameEn, String nameZh);

	public int delete(int bid);

	public Brand get(int bid);

	public List<Brand> all();
}
