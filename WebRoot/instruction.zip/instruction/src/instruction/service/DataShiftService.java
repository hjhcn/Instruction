package instruction.service;

public interface DataShiftService {
	public int dataShift();

	public void brandMerge();

	public void docConverter();
}
