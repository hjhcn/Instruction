package instruction.service;

import java.util.Map;

import instruction.model.LoginUser;
import instruction.model.User;

public interface UserService {
	public User get(int uid);

	public void save(User user);

	public LoginUser login(String smsphone, String password, String ip);

	public int queryLfb(String smsphone);

	public User login(Map<String, String> codeMap, String ip);

}
