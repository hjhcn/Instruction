package instruction.service.impl;

import instruction.dao.UserDao;
import instruction.model.LoginUser;
import instruction.model.User;
import instruction.service.CreditService;
import instruction.service.UserService;
import instruction.util.Time;

import java.util.LinkedList;
import java.util.Map;

import com.fivestars.interfaces.bbs.client.UCClient;
import com.fivestars.interfaces.bbs.util.XMLHelper;

public class UserServiceImpl implements UserService {
	private UserDao userDao;
	public CreditService creditService;

	public void setCreditService(CreditService creditService) {
		this.creditService = creditService;
	}

	public User get(int uid) {
		return userDao.get(uid);
	}

	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}

	public void save(User user) {
		userDao.saveOrUpdate(user);
	}

	public synchronized LoginUser login(String loginname, String password,
			String ip) {
		LoginUser loginUser = new LoginUser();
		UCClient uc = new UCClient();
		try {
			String result = uc.uc_user_login(loginname, password, ip);
			LinkedList<String> rs = XMLHelper.uc_unserialize(result);
			if (rs.size() > 0) {
				int uid = Integer.parseInt(rs.get(0));
				String username = rs.get(1);
				String email = rs.get(3);
				String smsphone = rs.get(4);

				loginUser.setFeedback(uid);
				if (uid > 0) {
					User user = userDao.get(uid);
					if (user == null) {
						user = new User();
						user.setUid(uid);
						user.setSmsphone(smsphone);
						user.setRegip(ip);
						user.setRegtime(Time.getTimeStamp());
						user.setCredit(0);
						creditService.addCredit(1, null, user);
					}
					user.setUsername(username);
					user.setSmsphone(smsphone);
					user.setEmail(email);
					user.setDateline(Time.getTimeStamp());
					user.setLogintime(Time.getTimeStamp());
					user.setLastip(ip);
					userDao.saveOrUpdate(user);
					loginUser.setLfb(this.queryLfb(loginname));
					loginUser.setUser(user);
					loginUser.setSync(uc.uc_user_synlogin(uid));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return loginUser;
	}

	public int queryLfb(String smsphone) {
		int lfb = 0;
		try {
			UCClient uc = new UCClient();
			String result = uc.uc_credit_querylfb(smsphone);
			LinkedList<String> rs = XMLHelper.uc_unserialize(result);
			lfb = Integer.parseInt(rs.get(0));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return lfb;
	}

	public User login(Map<String, String> codeMap, String ip) {
		int uid = Integer.parseInt(codeMap.get("uid"));
		String smsphone = codeMap.get("tel");
		String email = codeMap.get("email");
		if (smsphone == null)
			smsphone = "";
		String username = codeMap.get("username");
		User user = userDao.get(uid);
		if (user == null) {
			user = new User();
			user.setUid(uid);
			user.setSmsphone(smsphone);
			user.setRegip(ip);
			user.setRegtime(Time.getTimeStamp());
			user.setCredit(0);
			user.setEmail("");
		}
		if (!smsphone.equals(""))
			user.setSmsphone(smsphone);
		if (!email.equals(""))
			user.setEmail(email);
		user.setUsername(username);
		user.setDateline(Time.getTimeStamp());
		user.setLogintime(Time.getTimeStamp());
		user.setLastip(ip);
		userDao.saveOrUpdate(user);
		return user;
	}

}
