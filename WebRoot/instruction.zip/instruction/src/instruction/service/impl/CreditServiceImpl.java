package instruction.service.impl;

import instruction.SystemConstants;
import instruction.dao.CreditLogDao;
import instruction.dao.CreditRuleDao;
import instruction.dao.UserDao;
import instruction.model.CreditLog;
import instruction.model.CreditRule;
import instruction.model.Instruction;
import instruction.model.User;
import instruction.service.CreditService;
import instruction.util.Time;
import instruction.util.page.PageView;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;

import com.fivestars.interfaces.bbs.client.UCClient;
import com.fivestars.interfaces.bbs.util.XMLHelper;

public class CreditServiceImpl implements CreditService {
	private CreditRuleDao creditRuleDao;
	private CreditLogDao creditLogDao;
	private UserDao userDao;

	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}

	public CreditRuleDao getCreditRuleDao() {
		return creditRuleDao;
	}

	public void setCreditRuleDao(CreditRuleDao creditRuleDao) {
		this.creditRuleDao = creditRuleDao;
	}

	public CreditLogDao getCreditLogDao() {
		return creditLogDao;
	}

	public void setCreditLogDao(CreditLogDao creditLogDao) {
		this.creditLogDao = creditLogDao;
	}

	public int addCredit(int crid, Instruction ins, User user) {
		return this.addCredit(crid, ins, user, 0, "");
	}

	public int addCredit(int crid, Instruction ins, User user, int credit,
			String description) {
		if (ins != null && crid == 4) {
			List<CreditLog> creditLogs = creditLogDao.findByProperty(
					"instruction.id", ins.getId());
			if (creditLogs != null && creditLogs.size() > 0)
				return SystemConstants.FEEDBACK.CREDIT_INS_HAVEADD;
		}
		CreditRule creditRule = creditRuleDao.get(crid);
		int creditValue = credit;
		if (creditValue == 0) {
			creditValue = creditRule.getCredit();
		}
		if (creditRule != null) {
			int daySum = creditLogDao.todaySumByUserAndRule(creditRule, user);
			int dayThreshold = creditRule.getDayThreshold();
			int monthSum = creditLogDao.monthSumByUserAndRule(creditRule, user);
			int monthThreshold = creditRule.getMonthThreshold();

			if (creditRule.getMonthThreshold() == 0
					|| (monthThreshold > 0 && (creditRule.getCredit()
							+ monthSum <= monthThreshold))
					|| (monthThreshold < 0 && (creditRule.getCredit()
							+ monthSum >= monthThreshold))) {
				if (creditRule.getDayThreshold() == 0
						|| (dayThreshold > 0 && (creditRule.getCredit()
								+ daySum <= dayThreshold))
						|| (dayThreshold < 0 && (creditRule.getCredit()
								+ daySum >= dayThreshold))) {
					boolean isYidongShuomingshu = false;
					if (ins != null
							&& (ins.getCategory().getId() == 113 || ins
									.getCategory().getParentId() == 113)) {
						isYidongShuomingshu = true;
						if (crid == 4)
							creditValue = 2 * creditValue;
					}

					CreditLog creditLog = new CreditLog();
					creditLog.setInstruction(ins);
					creditLog.setUser(user);
					creditLog.setCreditRule(creditRule);
					creditLog.setDateline(Time.getTimeStamp());
					creditLog.setCredit(creditValue);
					if (description == null || "".equals(description))
						description = creditRule.getDescription();
					if (crid == 4) {
						description = ins.getTitle() + "通过审核获得" + creditValue
								+ "来福币。";
						if (isYidongShuomingshu) {
							description += "（移动家庭终端说明书翻倍）!";
						}

					} else if (crid == 3) {
						description = "对" + ins.getTitle() + "的评论通过审核获得"
								+ creditValue + "来福币。";
					} else if (crid == 7) {
						description = ins.getTitle() + "下载并评论通过审核获得"
								+ creditValue + "来福币。";
					}
					creditLog.setDescription(description);

					if (creditValue != 0) {
						userDao.creditUpdate(user.getUid(), creditRule
								.getCredit());
						UCClient uc = new UCClient();
						try {
							String result = uc.uc_credit_operatelfb(user
									.getSmsphone(), user.getUid(), creditValue,
									description);
							LinkedList<String> rs = XMLHelper
									.uc_unserialize(result);
							if (rs.size() > 0) {
								int lfb = Integer.parseInt(rs.get(0));
								if (lfb > 0) {
									creditLog.setIsSync(new Short((short) 1));
								} else {
									creditLog.setIsSync(new Short((short) 0));
								}
							}
						} catch (Exception e) {
							creditLog.setIsSync(new Short((short) 0));
							e.printStackTrace();
						}
					} else {
						creditLog.setIsSync(new Short((short) 0));
					}
					creditLogDao.saveOrUpdate(creditLog);
					return SystemConstants.FEEDBACK.SUCCESS;
				} else {
					return SystemConstants.FEEDBACK.CREDIT_EXEED_THRESHOLD;
				}
			} else {
				return SystemConstants.FEEDBACK.CREDIT_EXEED_THRESHOLD;
			}
		} else
			return SystemConstants.FEEDBACK.CREDIT_RULE_ID_NOEXSIT;
	}

	public int editRule(CreditRule creditRuleInput) {
		CreditRule creditRule = creditRuleDao.get(creditRuleInput.getId());
		if (creditRule != null) {
			if (creditRuleInput.getCredit() < 0
					&& creditRuleInput.getDayThreshold() <= 0
					|| creditRuleInput.getCredit() > 0
					&& creditRuleInput.getDayThreshold() >= 0) {
				creditRule.setCredit(creditRuleInput.getCredit());
				creditRule.setName(creditRuleInput.getName());
				creditRule.setDescription(creditRuleInput.getDescription());
				creditRule.setDayThreshold(creditRuleInput.getDayThreshold());
				creditRuleDao.saveOrUpdate(creditRule);
				return SystemConstants.FEEDBACK.SUCCESS;
			} else
				return SystemConstants.FEEDBACK.CREDIT_THRESHOLD_ILLEGAL;

		} else
			return SystemConstants.FEEDBACK.CREDIT_RULE_ID_NOEXSIT;
	}

	public PageView<CreditLog> listNotificationLog(int crid, int uid,
			int startTimeStamp, int endTimeStamp, int pageNum, int pageSize) {
		ArrayList<String> whereClause = new ArrayList<String>();
		if (crid > 0)
			whereClause.add("creditRule.id=" + crid);
		if (uid > 0)
			whereClause.add("user.uid=" + uid);
		if (startTimeStamp < endTimeStamp) {
			whereClause.add("dateline>=" + startTimeStamp);
			whereClause.add("dateline<=" + endTimeStamp);
		}
		whereClause.add("credit!=0");
		whereClause.add("isSync=1");
		whereClause.add("description!=''");
		LinkedHashMap<String, String> orderbyClause = new LinkedHashMap<String, String>();
		orderbyClause.put("id", "desc");
		PageView<CreditLog> creditLogs = new PageView<CreditLog>(pageNum,
				pageSize);
		creditLogs.setQueryResult(creditLogDao.findScrollData(pageNum,
				pageSize, whereClause, orderbyClause));
		return creditLogs;
	}

	public PageView<CreditLog> listLog(int crid, int uid, int startTimeStamp,
			int endTimeStamp, int pageNum, int pageSize, String orderby,
			int sort) {
		ArrayList<String> whereClause = new ArrayList<String>();
		if (crid > 0)
			whereClause.add("creditRule.id=" + crid);
		if (uid > 0)
			whereClause.add("user.uid=" + uid);
		if (startTimeStamp < endTimeStamp) {
			whereClause.add("dateline>=" + startTimeStamp);
			whereClause.add("dateline<=" + endTimeStamp);
		}
		LinkedHashMap<String, String> orderbyClause = new LinkedHashMap<String, String>();
		String sortStr = "desc";
		if (sort == 0)
			sortStr = "asc";
		orderbyClause.put(orderby, sortStr);
		PageView<CreditLog> creditLogs = new PageView<CreditLog>(pageNum,
				pageSize);
		creditLogs.setQueryResult(creditLogDao.findScrollData(pageNum,
				pageSize, whereClause, orderbyClause));
		return creditLogs;
	}

	public PageView<CreditRule> listRule(int pageNum, int pageSize) {
		PageView<CreditRule> creditLogs = new PageView<CreditRule>(pageNum,
				pageSize);
		creditLogs.setQueryResult(creditRuleDao.findScrollData(pageNum,
				pageSize));
		return creditLogs;
	}

	public int editRule(int crid, int credit, String description,
			int dayThreshold, int monthThreshold) {
		CreditRule creditRule = creditRuleDao.get(crid);
		if (creditRule == null)
			return SystemConstants.FEEDBACK.CREDIT_RULE_ID_NOEXSIT;
		else {
			creditRule.setCredit(credit);
			creditRule.setDayThreshold(dayThreshold);
			creditRule.setMonthThreshold(monthThreshold);
			creditRule.setDescription(description);
			creditRuleDao.saveOrUpdate(creditRule);
			return SystemConstants.FEEDBACK.SUCCESS;
		}
	}

	public CreditRule get(int crid) {
		return creditRuleDao.get(crid);
	}

	public int getNewCount(int uid) {
		ArrayList<String> whereClause = new ArrayList<String>();
		whereClause.add("user.id=" + uid);
		whereClause.add("isSync=1");
		return creditLogDao.getCount(whereClause);
	}

	public int readAll(int uid) {
		List<CreditLog> creditLogs = creditLogDao.findByProperty("user.uid",
				uid);
		for (CreditLog creditLog : creditLogs) {
			creditLog.setIsNotified(new Short((short) 1));
			creditLogDao.saveOrUpdate(creditLog);
		}
		return 0;
	}

	public int reCredit(String ids) {
		int count = 0;
		String[] idArray = ids.split(",");
		for (String idStr : idArray) {
			try {
				int id = Integer.parseInt(idStr);
				CreditLog creditLog = creditLogDao.get(id);
				if (creditLog.getIsSync() == 0) {
					UCClient uc = new UCClient();
					try {
						User user = creditLog.getUser();
						String result = uc.uc_credit_operatelfb(user
								.getSmsphone(), user.getUid(), creditLog
								.getCredit(), creditLog.getDescription());
						LinkedList<String> rs = XMLHelper
								.uc_unserialize(result);
						if (rs.size() > 0) {
							int lfb = Integer.parseInt(rs.get(0));
							if (lfb > 0) {
								creditLog.setIsSync(new Short((short) 1));
								count++;
								creditLogDao.saveOrUpdate(creditLog);
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			} catch (NumberFormatException e) {
				e.printStackTrace();
			}
		}
		return count;
	}

}
