package instruction.service.impl;

import instruction.SystemConstants;
import instruction.dao.BrandDao;
import instruction.model.Brand;
import instruction.service.BrandService;
import instruction.util.page.PageView;

import java.util.ArrayList;
import java.util.List;

public class BrandServiceImpl implements BrandService {
	public BrandDao brandDao;

	public PageView<Brand> getByCid(int cid, int pageNum, int pageSize) {
		ArrayList<String> whereClause = new ArrayList<String>();
		if (cid > 0)
			whereClause.add("category.id=" + cid);
		PageView<Brand> brands = new PageView<Brand>(pageNum, pageSize);
		brands.setQueryResult(brandDao.findScrollData(pageNum, pageSize,
				whereClause));
		return brands;
	}

	public void setBrandDao(BrandDao brandDao) {
		this.brandDao = brandDao;
	}

	public int add(String name, String nameEn, String nameZh) {
		List<Brand> brands = brandDao.findByProperty("name", name);
		if (brands != null && brands.size() > 0) {
			return SystemConstants.FEEDBACK.BRAND_NAME_EXSIT;
		} else {
			Brand brand = new Brand();
			brand.setName(name);
			brand.setNameEn(nameEn);
			brand.setNameZh(nameZh);
			brandDao.saveOrUpdate(brand);
			return SystemConstants.FEEDBACK.SUCCESS;
		}
	}

	public int edit(int bid, String name, String nameEn, String nameZh) {
		Brand brand = brandDao.get(bid);
		if (brand == null) {
			return SystemConstants.FEEDBACK.BRAND_BID_NOEXSIT;
		} else {
			brand.setName(name);
			brand.setNameEn(nameEn);
			brand.setNameZh(nameZh);
			brandDao.saveOrUpdate(brand);
			return SystemConstants.FEEDBACK.SUCCESS;
		}
	}

	public int delete(int bid) {
		Brand brand = brandDao.get(bid);
		if (brand == null) {
			return SystemConstants.FEEDBACK.BRAND_BID_NOEXSIT;
		} else {
			brand.setCats(null);
			brandDao.saveOrUpdate(brand);
			brandDao.delete(brand);
			return SystemConstants.FEEDBACK.SUCCESS;
		}
	}

	public Brand get(int bid) {
		return brandDao.get(bid);
	}

	public List<Brand> all() {
		return brandDao.getAll();
	}

}
