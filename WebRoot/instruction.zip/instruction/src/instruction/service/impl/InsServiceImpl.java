package instruction.service.impl;

import instruction.SystemConstants;
import instruction.SystemConstants.OPERATE;
import instruction.SystemConstants.STATUS;
import instruction.dao.BrandDao;
import instruction.dao.InsDao;
import instruction.dao.UserDao;
import instruction.model.AdminStatistic;
import instruction.model.Brand;
import instruction.model.Category;
import instruction.model.File;
import instruction.model.InsOrderBy;
import instruction.model.InsUpload;
import instruction.model.Instruction;
import instruction.model.User;
import instruction.service.CategoryService;
import instruction.service.CreditService;
import instruction.service.InsService;
import instruction.util.FileUtils;
import instruction.util.Time;
import instruction.util.page.PageView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Random;
import java.util.Set;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

public class InsServiceImpl implements InsService {
	private InsDao insDao;
	private UserDao userDao;
	private BrandDao brandDao;
	private CategoryService categoryService;
	private CreditService creditService;

	public String dataExport(int startTime, int endTime) {

		try {
			String excelName = "已审核说明书("
					+ Time.formatTimeStamp(startTime, "yyyy-MM-dd") + "_"
					+ Time.formatTimeStamp(endTime, "yyyy-MM-dd") + ")";
			String fileName = excelName + ".xls";
			java.io.File file = new java.io.File(
					SystemConstants.DATA_TO_EXCEL_FOLDER
							+ new String(fileName.getBytes(), "ISO8859-1"));
			if (file.exists())
				return fileName;
			// ！！！！！！！！！！！这里存在文件不能更新的问题

			// 打开文件
			WritableWorkbook book = Workbook.createWorkbook(file);
			// 生成名为“第一页”的工作表，参数0表示这是第一页
			WritableSheet sheet = book.createSheet("已审核说明书", 0);
			// 在Label对象的构造子中指名单元格位置是第一列第一行(0,0)
			// 以及单元格内容为test
			Label label = new Label(0, 0, "ID");
			// 将定义好的单元格添加到工作表中
			sheet.addCell(label);
			/*
			 * 生成一个保存数字的单元格 必须使用Number的完整包路径，否则有语法歧义 单元格位置是第二列，第一行，值为789.123
			 */
			label = new Label(1, 0, "标题");
			sheet.addCell(label);

			ArrayList<String> whereClause = new ArrayList<String>();
			whereClause.add("updateTime>=" + startTime);
			whereClause.add("updateTime<=" + endTime);
			whereClause.add("status>=1");
			List<Instruction> inses = insDao.findAllData(whereClause, null,
					null);
			for (int i = 0; i < inses.size(); i++) {
				jxl.write.Number number = new jxl.write.Number(0, i + 1, inses
						.get(i).getId());
				sheet.addCell(number);
				label = new Label(1, i + 1, inses.get(i).getTitle());
				sheet.addCell(label);
			}

			// 写入数据并关闭文件
			book.write();
			book.close();
			return fileName;
		} catch (Exception e) {
			System.out.println(e);
		}
		return null;
	}

	public List<Instruction> findTopNew(int count) {
		return insDao.findTopNew(count);
	}

	public void verifyCountBath() {
		List<Instruction> inses = insDao.findAll();
		for (Instruction ins : inses) {
			Random random = new Random();
			int downRandom = random.nextInt(50);
			ins.setDownloadCount(ins.getDownloadCount() + downRandom);
			ins.setViewCount(ins.getViewCount() + downRandom
					+ random.nextInt(300));
			insDao.saveOrUpdate(ins);
		}
	}

	public List<Instruction> findTopData(int cid, int bid, int hasIcon,
			int pageSize, String groupby, String orderby, int sort, Short status) {
		ArrayList<String> whereClause = new ArrayList<String>();
		if (hasIcon > 0) {
			whereClause.add("iconUrl!=null");
			whereClause.add("iconUrl!=''");
		}
		if (cid > 0) {
			whereClause.add(CategoryFilter(cid));
		}
		if (bid > 0) {
			// if (cid > 0)
			whereClause.add("brand.id=" + bid);
		}
		if (status > 0)
			whereClause.add("status>=" + status);
		ArrayList<String> groupbyClause = new ArrayList<String>();
		if (groupby != null && !"".equals(groupby))
			groupbyClause.add(groupby);
		LinkedHashMap<String, String> orderbyClause = new LinkedHashMap<String, String>();
		if (InsOrderBy.include(orderby)) {
			String sortStr = "desc";
			if (sort == 0)
				sortStr = "asc";
			orderbyClause.put(orderby, sortStr);
		}
		return insDao.findTopData(pageSize, whereClause, groupbyClause,
				orderbyClause);
	}

	public PageView<Instruction> findScrollData(int uid, int pageNum,
			int pageSize, String orderby, int sort, Short status) {
		ArrayList<String> whereClause = new ArrayList<String>();
		if (uid > 0)
			whereClause.add("user.id=" + uid);
		if (status > 0)
			whereClause.add("status>=" + status);
		PageView<Instruction> inses = new PageView<Instruction>(pageNum,
				pageSize);
		LinkedHashMap<String, String> orderbyClause = new LinkedHashMap<String, String>();
		if (InsOrderBy.include(orderby)) {
			String sortStr = "desc";
			if (sort == 0)
				sortStr = "asc";
			orderbyClause.put(orderby, sortStr);
		}
		inses.setQueryResult(insDao.findScrollData(pageNum, pageSize,
				whereClause, orderbyClause));
		return inses;
	}

	public PageView<Instruction> findScrollData(int cid, int bid,
			String search, int pageNum, int pageSize, String orderby, int sort,
			Short status) {
		ArrayList<String> whereClause = new ArrayList<String>();
		if (cid > 0)
			whereClause.add(CategoryFilter(cid));
		if (bid > 0) {
			// if (cid > 0)
			whereClause.add("brand.id=" + bid);
		}
		if (search != null && !"".equals(search)) {
			whereClause.add("title like '%" + search + "%'");
		}
		if (status > 0)
			whereClause.add("status>=" + status);
		PageView<Instruction> inses = new PageView<Instruction>(pageNum,
				pageSize);
		LinkedHashMap<String, String> orderbyClause = new LinkedHashMap<String, String>();
		if (InsOrderBy.include(orderby)) {
			String sortStr = "desc";
			if (sort == 0)
				sortStr = "asc";
			orderbyClause.put(orderby, sortStr);
		}
		inses.setQueryResult(insDao.findScrollData(pageNum, pageSize,
				whereClause, orderbyClause));
		return inses;
	}

	public PageView<Instruction> findScrollDataCascade(int cid, int bid,
			String search, int pageNum, int pageSize, String orderby, int sort,
			Short status) {
		ArrayList<String> whereClause = new ArrayList<String>();
		if (cid > 0)
			whereClause.add("category.id=" + cid);
		if (bid > 0) {
			// if (cid > 0)
			whereClause.add("brand.id=" + bid);
		}
		if (search != null && !"".equals(search)) {
			whereClause.add("title like '%" + search + "%'");
		}
		if (status > 0)
			whereClause.add("status>=" + status);
		PageView<Instruction> inses = new PageView<Instruction>(pageNum,
				pageSize);
		LinkedHashMap<String, String> orderbyClause = new LinkedHashMap<String, String>();
		if (InsOrderBy.include(orderby)) {
			String sortStr = "desc";
			if (sort == 0)
				sortStr = "asc";
			orderbyClause.put(orderby, sortStr);
		}
		inses.setQueryResult(insDao.findScrollDataCascade(pageNum, pageSize,
				whereClause, orderbyClause));
		return inses;
	}

	public synchronized Instruction get(int id, Short status) {
		Instruction ins = insDao.get(id);
		ins.setViewCount(ins.getViewCount() + 1);
		insDao.saveOrUpdate(ins);
		if (ins.getStatus() < status)
			ins = null;
		return ins;
	}

	/**
	 * @param uid用户id
	 * @param insUpload上传的输入模型
	 * @return 返回操作結果（feedback）
	 */
	public synchronized int operate(int uid, InsUpload insUpload, Short status,
			OPERATE operate) {
		Instruction ins = new Instruction();
		User user = userDao.get(uid);
		boolean isNewFile = true;
		int time = Time.getTimeStamp();
		if (insUpload.getTitle() == null || insUpload.getTitle().equals(""))
			return SystemConstants.FEEDBACK.INS_TITLE_ILLEGAL;
		if ((operate == OPERATE.ADMIN_UPLOAD || operate == OPERATE.USER_UPLOAD)
				&& !checkTitle(insUpload.getTitle()))
			return SystemConstants.FEEDBACK.INS_TITLE_EXSIT;
		if (insUpload.getBid() <= 0
				&& insUpload.getBid() != SystemConstants.UPLOAD_BRAND_OTHER)
			return SystemConstants.FEEDBACK.INS_BRAND_ILLEGAL;
		if (insUpload.getCid() <= 0)
			return SystemConstants.FEEDBACK.INS_CATEGORY_ILLEGAL;
		if (insUpload.getIconUrl() == null || insUpload.getIconUrl().equals(""))
			return SystemConstants.FEEDBACK.INS_ICON_ILLEGAL;
		if (insUpload.getFileUrl() == null || insUpload.getFileUrl().equals(""))
			return SystemConstants.FEEDBACK.INS_FILE_ILLEGAL;
		if (operate == OPERATE.ADMIN_UPLOAD || operate == OPERATE.USER_UPLOAD) {
			ins.setUser(user);
			ins.setUploadTime(time);
			ins.setDownloadCount(0);
			ins.setViewCount(0);
			if (operate == OPERATE.USER_UPLOAD) {
				ins.setIsUserUpload(new Short((short) 1));
			} else {
				// 初始化下载浏览数据
				Random random = new Random();
				int downRandom = random.nextInt(20);
				ins.setDownloadCount(downRandom);
				ins.setViewCount(downRandom + random.nextInt(100));
			}
		} else if ((operate == OPERATE.EDIT)) {
			ins = insDao.get(insUpload.getId());
			if (ins == null)
				return SystemConstants.FEEDBACK.INS_ID_NOEXSIT;
			Set<File> files = ins.getFiles();
			for (File file : files) {
				if (insUpload.getFileUrl().equals(file.getFileUrl()))
					isNewFile = false;
			}
			String editUids = ins.getEditUids();
			if (editUids != null && !editUids.equals(""))
				editUids += ",";
			else
				editUids = "";
			editUids += uid;
			ins.setEditUids(editUids);
		}
		if (isNewFile) {
			// 转存图片
			FileUtils.movePath(SystemConstants.UPLOAD_FOLDER_TEMP
					+ insUpload.getIconUrl(), SystemConstants.UPLOAD_FOLDER
					+ insUpload.getIconUrl());
			// 转换并转存文件
			SystemConstants.docConverter.push(insUpload.getFileUrl());
		}
		ins.setUpdateTime(time);
		ins.setStatus(status);

		Category category = categoryService.get(insUpload.getCid());
		Brand brand = brandDao.get(insUpload.getBid());
		ins.setCategory(category);
		ins.setBrand(brand);
		ins.setModel(insUpload.getModel());
		ins.setIconUrl(insUpload.getIconUrl());
		ins.setTitle(insUpload.getTitle());
		ins.setDescription(insUpload.getDescription());
		ins.setG3Url(insUpload.getG3Url());
		ins.setServer(SystemConstants.UPLOAD_FOLDER_SERVER);
		if (isNewFile) {
			File file = new File();
			file.setFileUrl(insUpload.getFileUrl());
			file.setFileSize(0);
			file.setDescription(insUpload.getTitle());
			file.setInstruction(ins);// 待优化
			Set<File> files = new HashSet<File>();
			files.add(file);
			ins.setFiles(files);
		}

		// 修改brand和category，还差修改原来的-1
		if (brand != null) {
			brand.setCount(brand.getCount() + 1);
			brandDao.saveOrUpdate(brand);
		}
		category.setCount(category.getCount() + 1);
		categoryService.saveOrUpdate(category);

		insDao.saveOrUpdate(ins);
		return SystemConstants.FEEDBACK.SUCCESS;
	}

	public boolean checkTitle(String title) {
		List<Instruction> inses = insDao.findByProperty("title", title);
		if (inses.size() > 0)
			return false;
		else
			return true;
	}

	public int delete(int id) {
		Instruction ins = insDao.get(id);
		if (ins == null)
			return SystemConstants.FEEDBACK.INS_ID_NOEXSIT;
		else {
			insDao.delete(ins);
			return SystemConstants.FEEDBACK.SUCCESS;
		}
	}

	public int operate(String ids, OPERATE operate) {
		int count = 0;
		String[] idArray = ids.split(",");
		for (String idStr : idArray) {
			try {
				int id = Integer.parseInt(idStr);
				Instruction ins = insDao.get(id);
				if (ins != null) {
					if (operate == OPERATE.DELETE) {
						insDao.delete(ins);
					} else if (operate == OPERATE.VERIFY) {
						ins.setStatus(STATUS.PASS);
						insDao.saveOrUpdate(ins);
						if (ins.getIsUserUpload() == 1)
							creditService.addCredit(4, ins, ins.getUser());
					} else if (operate == OPERATE.UNVERIFY) {
						ins.setStatus(STATUS.UNVERIFY);
						insDao.saveOrUpdate(ins);
					}
					count++;
				}
			} catch (NumberFormatException e) {
				e.printStackTrace();
			}
		}
		return count;
	}

	public String CategoryFilter(int cid) {
		String categoryFilter = "category.id=" + cid;
		List<Category> categorys = categoryService.getTree(cid);
		for (Category category : categorys) {
			categoryFilter += " or category.id=" + category.getId();
		}
		return categoryFilter;
	}

	public synchronized File download(int iid, int fid, int uid) {
		File downloadFile = null;
		User user = userDao.get(uid);
		Instruction ins = insDao.get(iid);
		ins.setDownloadCount(ins.getDownloadCount() + 1);
		if (ins != null) {
			for (File file : ins.getFiles()) {
				downloadFile = file;
				if (file.getId() == fid)
					break;
			}
			if (downloadFile != null) {
				creditService.addCredit(2, ins, user);
			}
		}
		insDao.saveOrUpdate(ins);
		return downloadFile;
	}

	public List<AdminStatistic> statistic(int startTime, int endTime, int uid) {
		ArrayList<String> whereClause = new ArrayList<String>();
		whereClause.add("uploadTime>=" + startTime);
		whereClause.add("uploadTime<=" + endTime);
		if (uid > 0)
			whereClause.add("user.uid=" + uid);
		LinkedHashMap<String, String> orderbyClause = new LinkedHashMap<String, String>();
		ArrayList<String> groupClause = new ArrayList<String>();
		groupClause.add("user");
		if (uid > 0)
			groupClause.add("brand");
		List<AdminStatistic> statistics = insDao.statistic(whereClause,
				orderbyClause, groupClause);
		return statistics;
	}

	public int judageModel(InsUpload insUpload) {
		List<Instruction> inses = insDao.findByProperty("model", insUpload
				.getModel());
		if (inses.size() > 0)
			return SystemConstants.FEEDBACK.INS_MODEL_ILLEGAL;
		else
			return SystemConstants.FEEDBACK.SUCCESS;
	}

	public void reOrder(String orderStr) {
		String[] orderArray = orderStr.split(",");
		for (String idStr : orderArray) {
			String[] itemArray = idStr.split("|");
			if (itemArray.length == 2) {
				try {
					int id = Integer.parseInt(itemArray[0]);
					int order = Integer.parseInt(itemArray[1]);
					Instruction ins = insDao.get(id);
					if (ins != null) {
						ins.setOrder(order);
						insDao.saveOrUpdate(ins);
					}
				} catch (NumberFormatException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public void setCreditService(CreditService creditService) {
		this.creditService = creditService;
	}

	public void setInsDao(InsDao insDao) {
		this.insDao = insDao;
	}

	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}

	public void setBrandDao(BrandDao brandDao) {
		this.brandDao = brandDao;
	}

	public void setCategoryService(CategoryService categoryService) {
		this.categoryService = categoryService;
	}

	public int reCoverter(int id) {
		Instruction ins = insDao.get(id);
		if (ins == null)
			return SystemConstants.FEEDBACK.INS_ID_NOEXSIT;
		Set<File> files = ins.getFiles();
		if (files != null && files.size() == 1) {
			File file = (File) files.toArray()[0];
			System.out.println("再次请求:" + file.getFileUrl());
			FileUtils.copyPath(file.getRealPath(),
					SystemConstants.UPLOAD_FOLDER_TEMP + file.getFileUrl());
			SystemConstants.docConverter.push(file.getFileUrl());
		}
		return SystemConstants.FEEDBACK.SUCCESS;
	}

}
