package instruction.service.impl;

import instruction.SystemConstants;
import instruction.dao.BrandDao;
import instruction.dao.CategoryDao;
import instruction.dao.InsDao;
import instruction.dao.PhpcmsDao;
import instruction.dao.UserDao;
import instruction.model.Brand;
import instruction.model.File;
import instruction.model.Instruction;
import instruction.model.PhpcmsCDownload;
import instruction.model.PhpcmsContent;
import instruction.service.DataShiftService;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

public class DataShiftServiceImpl implements DataShiftService {
	private PhpcmsDao phpcmsContentDao;
	private InsDao insDao;
	private CategoryDao categoryDao;
	private BrandDao brandDao;
	private UserDao userDao;

	public UserDao getUserDao() {
		return userDao;
	}

	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}

	public void docConverter() {
		ArrayList<String> whereClause = new ArrayList<String>();
		ArrayList<String> groupbyClause = new ArrayList<String>();
		LinkedHashMap<String, String> orderbyClause = new LinkedHashMap<String, String>();
		orderbyClause.put("id", "desc");
		List<Instruction> inses = insDao.findTopData(100000, whereClause,
				groupbyClause, orderbyClause);
		for (Instruction ins : inses) {
			Set<File> files = ins.getFiles();
			if (files!=null&&files.size() == 1) {
				File file = (File) files.toArray()[0];
				System.out.println(SystemConstants.UPLOAD_FOLDER
						+ file.getFileUrl());
				SystemConstants.docConverter.push(SystemConstants.UPLOAD_FOLDER
						+ file.getFileUrl());
			}
		}
	}

	public void brandMerge() {
		List<Brand> brands = brandDao.getAll();
		for (Brand brand : brands) {
			if (brand.getIconUrl() != null && !"".equals(brand.getIconUrl())) {
				int bid = Integer.parseInt(brand.getIconUrl());
				Brand mergeBrand = brandDao.get(bid);
				if (mergeBrand != null) {
					mergeBrand.setCount(mergeBrand.getCount()
							+ brand.getCount());
					brandDao.save(mergeBrand);
					List<Instruction> inses = insDao.findByProperty("brand.id",
							bid);
					for (Instruction ins : inses) {
						ins.setBrand(mergeBrand);
						insDao.saveOrUpdate(ins);
					}
					brandDao.delete(brand);
				}
			}
		}
	}

	public int dataShift() {
		List<PhpcmsContent> pcs = phpcmsContentDao.getAll();
		for (PhpcmsContent pc : pcs) {
			PhpcmsCDownload download = pc.getDownload();
			if (download != null) {
				Instruction ins;
				if (pc.getShiftstatus() == 0)
					ins = new Instruction();
				else {
					List<Instruction> inses = insDao.findByProperty(
							"uploadTime", pc.getInputtime());
					if (inses.size() > 0)
						ins = inses.get(0);
					else
						ins = new Instruction();
				}
				Short shiftstatus = 1;
				ins.setTitle(pc.getTitle());
				ins.setIconUrl(pc.getThumb());
				ins.setUploadTime(pc.getInputtime());
				ins.setUpdateTime(pc.getUpdatetime());
				ins.setCategory(categoryDao.get(pc.getCid()));
				pc.setShiftstatus(shiftstatus);
				phpcmsContentDao.save(pc);

				Set<File> files = new HashSet<File>();
				String[] fileSizeStrs = (download.getFilesize()).split(" ");
				int fileSize = 0;
				if (fileSizeStrs.length > 0) {
					try {
						fileSize = Integer.parseInt(fileSizeStrs[0]);
					} catch (NumberFormatException e) {

					}
				}
				String[] downurls = download.getDownurls().split("\n");
				for (String downurl : downurls) {
					String[] down = downurl.split("\\|");
					if (down.length >= 2) {
						File file = new File();
						file.setDescription(down[0]);
						file.setFileUrl(down[1].substring(11));
						file.setFileSize(fileSize);
						file.setInstruction(ins);
						files.add(file);
					}
				}
				ins.setDescription(download.getContent());
				ins.setFiles(files);
				ins.setUser(userDao.get(pc.getUid()));
				insDao.saveOrUpdate(ins);
			}
		}
		return SystemConstants.FEEDBACK.SUCCESS;
	}

	public int dataShiftOld() {
		List<PhpcmsContent> pcs = phpcmsContentDao.getAllNewContent();
		for (PhpcmsContent pc : pcs) {
			PhpcmsCDownload download = pc.getDownload();
			if (download != null) {
				Short shiftstatus = 1;
				Instruction ins = new Instruction();
				ins.setTitle(pc.getTitle());
				ins.setIconUrl(pc.getThumb());
				ins.setUploadTime(pc.getInputtime());
				ins.setUpdateTime(pc.getUpdatetime());
				ins.setCategory(categoryDao.get(pc.getCid()));
				if (pc.getBrand() == null)
					shiftstatus = 2;
				else {
					List<Brand> brands = brandDao.getByName(pc.getBrand());
					if (brands == null || brands.size() == 0) {
						Brand brand = new Brand();
						brand.setName(pc.getBrand());
						brand.setCount(1);
						brand.setIsHot(Short.valueOf((short) 0));
						brandDao.save(brand);
						ins.setBrand(brand);
					} else {
						Brand brand = brands.get(0);
						brand.setCount(brand.getCount() + 1);
						ins.setBrand(brands.get(0));
					}
				}
				pc.setShiftstatus(shiftstatus);
				phpcmsContentDao.save(pc);

				Set<File> files = new HashSet<File>();
				String[] fileSizeStrs = (download.getFilesize()).split(" ");
				int fileSize = 0;
				if (fileSizeStrs.length > 0) {
					try {
						fileSize = Integer.parseInt(fileSizeStrs[0]);
					} catch (NumberFormatException e) {

					}
				}
				String[] downurls = download.getDownurls().split("\n");
				for (String downurl : downurls) {
					String[] down = downurl.split("\\|");
					if (down.length >= 2) {
						File file = new File();
						file.setDescription(down[0]);
						file.setFileUrl(down[1]);
						file.setFileSize(fileSize);
						file.setInstruction(ins);
						files.add(file);
					}
				}
				ins.setDescription(download.getContent());
				ins.setFiles(files);
				insDao.saveOrUpdate(ins);
			}
		}
		this.brandMerge();
		return SystemConstants.FEEDBACK.SUCCESS;
	}

	public void setCategoryDao(CategoryDao categoryDao) {
		this.categoryDao = categoryDao;
	}

	public void setPhpcmsContentDao(PhpcmsDao phpcmsContentDao) {
		this.phpcmsContentDao = phpcmsContentDao;
	}

	public void setInsDao(InsDao insDao) {
		this.insDao = insDao;
	}

	public void setBrandDao(BrandDao brandDao) {
		this.brandDao = brandDao;
	}

}
