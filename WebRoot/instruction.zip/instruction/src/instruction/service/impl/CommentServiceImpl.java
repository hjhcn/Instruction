package instruction.service.impl;

import instruction.SystemConstants;
import instruction.dao.CommentDao;
import instruction.dao.InsDao;
import instruction.dao.UserDao;
import instruction.model.Comment;
import instruction.model.Instruction;
import instruction.model.User;
import instruction.model.UserSession;
import instruction.service.CommentService;
import instruction.service.CreditService;
import instruction.util.Time;
import instruction.util.page.PageView;

import java.util.ArrayList;
import java.util.LinkedHashMap;

public class CommentServiceImpl implements CommentService {
	public CommentDao commentDao;
	public UserDao userDao;
	public InsDao insDao;
	public CreditService creditService;

	public void setCreditService(CreditService creditService) {
		this.creditService = creditService;
	}

	public int post(UserSession userSession, int iid, Short grade,
			String content) {
		User user = userDao.get(userSession.getUid());
		if (user == null)
			return SystemConstants.FEEDBACK.UID_ERROR;
		else {
			Instruction ins = insDao.get(iid);
			if (grade < 1 || grade > 5)
				return SystemConstants.FEEDBACK.COMMENT_GRADE_ERROR;
			else if (null == content || "".equals(content))
				return SystemConstants.FEEDBACK.COMMENT_CONTENT_ERROR;
			else {
				Comment comment = new Comment();
				comment.setUser(user);
				comment.setUsername(userSession.getUsername());
				comment.setDateline(Time.getTimeStamp());
				comment.setGrade(grade);
				comment.setInstruction(ins);
				comment.setIp(userSession.getIp());
				comment.setContent(content);
				comment.setCreditStatus(new Short((short)0));
				commentDao.saveOrUpdate(comment);
				
				//积分取消
				//
				
				return SystemConstants.FEEDBACK.SUCCESS;
			}
		}
	}

	public PageView<Comment> findScrollData(int iid, int pageNum, int pageSize) {
		PageView<Comment> pageView = new PageView<Comment>(pageNum, pageSize);
		ArrayList<String> whereClause = new ArrayList<String>();
		if(iid>0)whereClause.add("instruction.id=" + iid);
		LinkedHashMap<String, String> orderbyClause = new LinkedHashMap<String, String>();
		orderbyClause.put("id", "desc");
		pageView.setQueryResult(commentDao.findScrollData(pageNum, pageSize,
				whereClause, orderbyClause));
		return pageView;
	}
	
	public int credit(String ids, Short creditStatus){
		int count = 0;
		String[] idArray = ids.split(",");
		for (String idStr : idArray) {
			try {
				int id = Integer.parseInt(idStr);
				Comment comment = commentDao.get(id);
				if(comment.getCreditStatus()<creditStatus){
				   comment.setCreditStatus(creditStatus);
				   commentDao.saveOrUpdate(comment);
				   if(creditStatus==2){
					   creditService.addCredit(3,comment.getInstruction(), comment.getUser());
				   }
				   count++;
				}
			} catch (NumberFormatException e) {
				e.printStackTrace();
			}
		}
		return count;
	}

	public void setCommentDao(CommentDao commentDao) {
		this.commentDao = commentDao;
	}

	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}

	public void setInsDao(InsDao insDao) {
		this.insDao = insDao;
	}

}
