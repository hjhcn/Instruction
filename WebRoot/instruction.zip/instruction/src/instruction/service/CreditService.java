package instruction.service;

import instruction.model.CreditLog;
import instruction.model.CreditRule;
import instruction.model.Instruction;
import instruction.model.User;
import instruction.util.page.PageView;

public interface CreditService {
	public PageView<CreditRule> listRule(int pageNum, int pageSize);

	public PageView<CreditLog> listLog(int crid, int uid, int startTimeStamp,
			int endTimeStamp, int pageNum, int pageSize, String orderby, int sort);
	
	public PageView<CreditLog> listNotificationLog(int crid, int uid, int startTimeStamp,
			int endTimeStamp, int pageNum, int pageSize);

	public int editRule(CreditRule creditRule);

	public int addCredit(int crid, Instruction ins, User user);
	
	public int addCredit(int crid, Instruction ins, User user, int credit, String description);

	public int editRule(int crid, int credit, String description,
			int dayThreshold,int monthThreshold);

	public CreditRule get(int crid);
	
	public int getNewCount(int uid);

	public int readAll(int uid);

	public int reCredit(String ids);

}
