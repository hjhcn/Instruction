package instruction.action;

import instruction.model.Comment;
import instruction.model.UserSession;
import instruction.service.CommentService;
import instruction.util.page.PageView;

public class CommentAction extends SessionBaseAction {

	private static final long serialVersionUID = -6099566024995318676L;
	private PageView<Comment> pageView;
	private int iid;
	private int pageNum = 1;
	private int pageSize = 10;
	private CommentService commentService;
	private short grade = 1;
	private String content = "";

	public String post() {
		feedback = commentService.post(userSession, iid, grade, content);
		return SUCCESS;
	}

	public String list() {
		pageView = commentService.findScrollData(iid, pageNum, pageSize);
		return SUCCESS;
	}

	public UserSession getUserSession() {
		return userSession;
	}

	public CommentService getCommentService() {
		return commentService;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public void setPageNum(int pageNum) {
		this.pageNum = pageNum;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public PageView<Comment> getPageView() {
		return pageView;
	}

	public void setIid(int iid) {
		this.iid = iid;
	}

	public void setCommentService(CommentService commentService) {
		this.commentService = commentService;
	}

	public int getFeedback() {
		return feedback;
	}

	public void setGrade(short grade) {
		this.grade = grade;
	}
}
