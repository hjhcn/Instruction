package instruction.action;

import instruction.SystemConstants;
import instruction.model.UserSession;
import instruction.rules.FeedbackRule;
import instruction.rules.UserSessionRule;
import instruction.util.CookieUtils;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionSupport;

public class SessionBaseAction extends ActionSupport implements SessionAware,
		ServletRequestAware, ServletResponseAware, UserSessionRule,
		FeedbackRule {
	private static final long serialVersionUID = 1L;
	public Map<String, Object> session;
	public HttpServletResponse response;
	public HttpServletRequest request;
	public CookieUtils cookieUtils = new CookieUtils();
	public UserSession userSession;
	public int feedback = SystemConstants.FEEDBACK.SUCCESS;

	public void setSession(Map<String, Object> session) {
		this.session = session;
	}

	public void setServletRequest(HttpServletRequest request) {
		this.request = request;
	}

	public void setServletResponse(HttpServletResponse response) {
		this.response = response;
	}

	public void setUserSession(UserSession userSession) {
		this.userSession = userSession;
	}

	public UserSession getUserSession() {
		return userSession;
	}

	public void setFeedback(int feedback) {
		this.feedback = feedback;
	}
}
