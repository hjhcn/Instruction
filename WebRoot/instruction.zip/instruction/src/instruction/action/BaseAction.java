package instruction.action;

import instruction.SystemConstants;
import instruction.rules.FeedbackRule;

import com.opensymphony.xwork2.ActionSupport;

public class BaseAction extends ActionSupport implements FeedbackRule {
	private static final long serialVersionUID = 4186341131437455986L;
	public int feedback = SystemConstants.FEEDBACK.SUCCESS;

	public void setFeedback(int feedback) {
		this.feedback = feedback;
	}

}
