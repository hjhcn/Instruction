package instruction.action;

import instruction.SystemConstants;
import instruction.SystemConstants.OPERATE;
import instruction.SystemConstants.STATUS;
import instruction.model.BBSThread;
import instruction.model.Category;
import instruction.model.Daren;
import instruction.model.File;
import instruction.model.InsUpload;
import instruction.model.Instruction;
import instruction.service.BBSThreadService;
import instruction.service.CategoryService;
import instruction.service.InsService;
import instruction.util.FileUtils;
import instruction.util.page.PageView;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.List;

public class InsAction extends SessionBaseAction {

	private static final long serialVersionUID = 3176034408820731405L;
	private InsService insService;
	private CategoryService categoryService;
	private BBSThreadService bbsThreadService;
	private int id;
	private Instruction ins;
	private PageView<Instruction> inses;
	private int cid = 0;
	private int bid = 0;
	private int pageNum = 1;
	private int pageSize = 10;
	private String orderby = "updateTime";
	private int sort = 1;
	private List<BBSThread> threads;
	private List<Category> cates;
	private String search;
	private InsUpload insUpload;
	private java.io.File file;
	private String fileFileName;
	private String fileFolderAndName;
	private List<Category> categorys;
	private List<Daren> darens = SystemConstants.darens;
	private InputStream fileDownload;
	private String filename;
	private String contentType;
	private int fid;

	public String verifyCountBath() {
		// insService.verifyCountBath();
		return SUCCESS;
	}

	public String execute() {
		ins = insService.get(id, SystemConstants.STATUS.PASS);
		if (ins != null) {
			for (File file : ins.getFiles()) {
				if (null == file.getDescription()
						|| "".equals(file.getDescription())) {
					file.setDescription(ins.getTitle());
				}
			}
			cates = categoryService.findRelated(ins.getCategory());
		}
		threads = bbsThreadService.findTop(10);
		return SUCCESS;
	}

	public String list() {
		inses = insService.findScrollData(cid, bid, search, pageNum, pageSize,
				orderby, sort, SystemConstants.STATUS.PASS);
		cates = categoryService.getTree(0);
		threads = bbsThreadService.findTop(10);
		return SUCCESS;
	}

	public String listInsOfUser() {
		inses = insService.findScrollData(userSession.getUid(), pageNum,
				pageSize, orderby, sort, SystemConstants.STATUS.SHOWALL);
		threads = bbsThreadService.findTop(10);
		return SUCCESS;
	}

	public String upload() {
		feedback = insService.operate(userSession.getUid(), insUpload,
				STATUS.UNVERIFY, OPERATE.USER_UPLOAD);
		return SUCCESS;
	}

	public String download() {
		File downloadFile = insService.download(id, fid, userSession.getUid());
		if (downloadFile != null) {
			try {
				filename = new String((downloadFile.getDescription())
						.getBytes(), "ISO8859-1");
				try {
					fileDownload = new FileInputStream(downloadFile
							.getUploadFolder()
							+ downloadFile.getFileUrl());
					System.out.println(downloadFile.getUploadFolder()
							+ downloadFile.getFileUrl());
					String ext = FileUtils.getExt(downloadFile.getFileUrl());
					if (ext.equals("docx"))
						contentType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
					else if (ext.equals("pptx"))
						contentType = "application/vnd.openxmlformats-officedocument.presentationml.presentation";
					else if (ext.equals("xlsx"))
						contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
					else if (ext.equals("doc"))
						contentType = "application/msword";
					else if (ext.equals("ppt"))
						contentType = "application/vnd.ms-powerpoint";
					else if (ext.equals("xls"))
						contentType = "application/vnd.ms-excel";
					else if (ext.equals("swf"))
						contentType = "application/x-shockwave-flash";
				} catch (FileNotFoundException e) {
					try {
						fileDownload = new FileInputStream(downloadFile
								.getUploadFolder()
								+ FileUtils.getPre(downloadFile.getFileUrl())
								+ ".swf");
						contentType = "application/x-shockwave-flash";
					} catch (FileNotFoundException fileEx) {
						e.printStackTrace();
					}
				}

			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
		}
		return "file";
	}

	public String uploadFile() {
		String time = FileUtils.getFilenameByTime();
		String ext = fileFileName.substring(fileFileName.lastIndexOf("."))
				.toLowerCase();
		String newFileName = time + "_" + userSession.getUid() + ext;
		String folder = FileUtils.getFileFolderByTime(time);
		// 添加server目录，增加137服务器共享空间
		// 2012-11-22
		fileFolderAndName = folder + newFileName;
		folder = SystemConstants.UPLOAD_FOLDER_TEMP + folder;
		FileUtils.upload(folder, newFileName, file);
		return SUCCESS;
	}

	public String uploadPage() {
		threads = bbsThreadService.findTop(10);
		setCategorys(categoryService.getTree(0));
		return SUCCESS;
	}

	public void setSearch(String search) {
		this.search = search;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public void setBid(int bid) {
		this.bid = bid;
	}

	public int getCid() {
		return cid;
	}

	public int getBid() {
		return bid;
	}

	public void setPageNum(int pageNum) {
		this.pageNum = pageNum;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public void setOrderby(String orderby) {
		this.orderby = orderby;
	}

	public void setSort(int sort) {
		this.sort = sort;
	}

	public Instruction getIns() {
		return ins;
	}

	public void setInsService(InsService insService) {
		this.insService = insService;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public PageView<Instruction> getInses() {
		return inses;
	}

	public void setThreads(List<BBSThread> threads) {
		this.threads = threads;
	}

	public List<BBSThread> getThreads() {
		return threads;
	}

	public List<Category> getCates() {
		return cates;
	}

	public void setCategoryService(CategoryService categoryService) {
		this.categoryService = categoryService;
	}

	public String getSearch() {
		return search;
	}

	public InsUpload getInsUpload() {
		return insUpload;
	}

	public void setInsUpload(InsUpload insUpload) {
		this.insUpload = insUpload;
	}

	public String getFileFileName() {
		return fileFileName;
	}

	public void setFileFileName(String fileFileName) {
		this.fileFileName = fileFileName;
	}

	public String getFileFolderAndName() {
		return fileFolderAndName;
	}

	public void setFileFolderAndName(String fileFolderAndName) {
		this.fileFolderAndName = fileFolderAndName;
	}

	public void setCategorys(List<Category> categorys) {
		this.categorys = categorys;
	}

	public List<Category> getCategorys() {
		return categorys;
	}

	public java.io.File getFile() {
		return file;
	}

	public void setFile(java.io.File file) {
		this.file = file;
	}

	public int getFeedback() {
		return this.feedback;
	}

	public void setDarens(List<Daren> darens) {
		this.darens = darens;
	}

	public List<Daren> getDarens() {
		return darens;
	}

	public void setFileDownload(InputStream fileDownload) {
		this.fileDownload = fileDownload;
	}

	public InputStream getFileDownload() {
		return fileDownload;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public String getFilename() {
		return filename;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public int getFid() {
		return fid;
	}

	public void setFid(int fid) {
		this.fid = fid;
	}

	public void setBbsThreadService(BBSThreadService bbsThreadService) {
		this.bbsThreadService = bbsThreadService;
	}

	public BBSThreadService getBbsThreadService() {
		return bbsThreadService;
	}

}
