package instruction.action.admin;

import instruction.model.Brand;
import instruction.service.BrandService;
import instruction.util.page.PageView;

public class BrandAdminAction extends BaseAdminAction {
	private static final long serialVersionUID = 7930453330829478289L;
	private BrandService brandService;
	private int cid = 0;
	private PageView<Brand> brands;
	private int pageNum = 1;
	private int pageSize = 20;
	private int bid = 0;
	private String name;
	private String nameEn;
	private String nameZh;
	private Brand brand;

	public String list() {
		brands = brandService.getByCid(cid, pageNum, pageSize);
		return SUCCESS;
	}

	public String brand() {
		setBrand(brandService.get(bid));
		return SUCCESS;
	}

	public String addPage() {
		return SUCCESS;
	}

	public String add() {
		feedback = brandService.add(name, nameEn, nameZh);
		return SUCCESS;
	}

	public String edit() {
		feedback = brandService.edit(bid, name, nameEn, nameZh);
		return SUCCESS;
	}

	public String delete() {
		feedback = brandService.delete(bid);
		return SUCCESS;
	}

	public void setBrandService(BrandService brandService) {
		this.brandService = brandService;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public int getCid() {
		return cid;
	}

	public void setBrands(PageView<Brand> brands) {
		this.brands = brands;
	}

	public PageView<Brand> getBrands() {
		return brands;
	}

	public int getPageNum() {
		return pageNum;
	}

	public void setPageNum(int pageNum) {
		this.pageNum = pageNum;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public int getFeedback() {
		return this.feedback;
	}

	public int getBid() {
		return bid;
	}

	public void setBid(int bid) {
		this.bid = bid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNameEn() {
		return nameEn;
	}

	public void setNameEn(String nameEn) {
		this.nameEn = nameEn;
	}

	public String getNameZh() {
		return nameZh;
	}

	public void setNameZh(String nameZh) {
		this.nameZh = nameZh;
	}

	public void setBrand(Brand brand) {
		this.brand = brand;
	}

	public Brand getBrand() {
		return brand;
	}
}
