package instruction.action.admin;

import instruction.model.User;
import instruction.service.UserService;

public class UserAdminAction extends BaseAdminAction {
//未启用
	private static final long serialVersionUID = 1979680168642525015L;
	private UserService userService;
	private int pageNum = 1;
	private int pageSize = 10;
	private int startTimeStamp = 0;
	private int endTimeStamp = 0;
	private int uid = 0;
	private int username;
	private String smsphone;
	private User user;
	
	
	public UserService getUserService() {
		return userService;
	}
	public void setUserService(UserService userService) {
		this.userService = userService;
	}
	public int getPageNum() {
		return pageNum;
	}
	public void setPageNum(int pageNum) {
		this.pageNum = pageNum;
	}
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	public int getStartTimeStamp() {
		return startTimeStamp;
	}
	public void setStartTimeStamp(int startTimeStamp) {
		this.startTimeStamp = startTimeStamp;
	}
	public int getEndTimeStamp() {
		return endTimeStamp;
	}
	public void setEndTimeStamp(int endTimeStamp) {
		this.endTimeStamp = endTimeStamp;
	}
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public int getUsername() {
		return username;
	}
	public void setUsername(int username) {
		this.username = username;
	}
	public String getSmsphone() {
		return smsphone;
	}
	public void setSmsphone(String smsphone) {
		this.smsphone = smsphone;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public User getUser() {
		return user;
	}
	
	
}
