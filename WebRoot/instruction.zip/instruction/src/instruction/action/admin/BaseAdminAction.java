package instruction.action.admin;

import instruction.SystemConstants;
import instruction.model.Admin;
import instruction.rules.AdminSessionRule;
import instruction.rules.FeedbackRule;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionSupport;

public class BaseAdminAction extends ActionSupport implements SessionAware,
		ServletRequestAware, ServletResponseAware, AdminSessionRule,
		FeedbackRule {

	private static final long serialVersionUID = 2157561654358344088L;
	public Map<String, Object> session;
	public HttpServletResponse response;
	public HttpServletRequest request;
	public Admin admin;
	public int feedback = SystemConstants.FEEDBACK.SUCCESS;

	public void setSession(Map<String, Object> session) {
		this.session = session;
	}

	public void setServletRequest(HttpServletRequest request) {
		this.request = request;
	}

	public void setServletResponse(HttpServletResponse response) {
		this.response = response;
	}

	public void setAdminSession(Admin admin) {
		this.admin = admin;
	}

	public void setFeedback(int feedback) {
		this.feedback = feedback;
	}

}
