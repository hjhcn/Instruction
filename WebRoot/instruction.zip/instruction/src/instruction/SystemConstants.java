package instruction;

import instruction.model.Daren;
import instruction.util.DecompFile;
import instruction.util.DocConverter;

import java.util.ArrayList;
import java.util.List;

public class SystemConstants {
	public static final String USER_SESSION = "user.session";
	public static final String USER_COOKIE = "user.cookie";
	public static final String ADMIN_SESSION = "admin";

	public static final String UPLOAD_FOLDER_TEMP = "F:/uploadfileTemp/";

	// public static final String UPLOAD_FOLDER =
	// "E:/ins_uploadfile/";
	public static final String UPLOAD_FOLDER = "//192.168.0.137/ins_uploadfile/";
	public static final String UPLOAD_FOLDER_SERVER = "server137";

	public static final String OLD_UPLOAD_FOLDER = "F:/uploadfile/";
	public static final String OLD_UPLOAD_FOLDER_SERVER = "server138";

	public static final String DATA_TO_EXCEL_FOLDER = "F:/dataToExcel/";

	public static final int UPLOAD_BRAND_OTHER = -12345;

	public static final class STATUS {
		public static final Short PASS = new Short((short) 1);
		public static final Short UNVERIFY = new Short((short) 0);
		public static final Short DELETED = new Short((short) -1);
		public static final Short SHOWALL = new Short((short) -100);
	}

	public static enum OPERATE {
		ADMIN_UPLOAD, USER_UPLOAD, EDIT, DELETE, VERIFY, UNVERIFY;
	}

	public static final class FEEDBACK {
		public static final int SUCCESS = 100;

		public static final int LOGIN_ERROR = -101;
		public static final int UID_ERROR = -102;// 用户Uid不存在

		public static final int UNLOGIN_ERROR = -201;// 未登录错误

		public static final int IID_ERROR = -301;// 说明书id不存在

		public static final int COMMENT_GRADE_ERROR = -401;
		public static final int COMMENT_CONTENT_ERROR = -402;

		public static final int ADMIN_UNLOGIN_ERROR = -501;// 未登录错误
		public static final int ADMIN_USERNAME_NOTEXSIT = -502;// 管理用户名不存在
		public static final int ADMIN_LOGIN_PASW_ERROR = -503;// 登录密码错失败
		public static final int ADMIN_UID_NOTEXSIT = -504;// 管理员Uid不存在
		public static final int ADMIN_NEW_PASW_ERROR = -505;// 新密码格式错

		public static final int INS_ID_NOEXSIT = -601;
		public static final int INS_TITLE_EXSIT = -602;
		public static final int INS_TITLE_ILLEGAL = -603;
		public static final int INS_CATEGORY_ILLEGAL = -604;
		public static final int INS_BRAND_ILLEGAL = -605;
		public static final int INS_ICON_ILLEGAL = -606;
		public static final int INS_FILE_ILLEGAL = -607;
		public static final int INS_MODEL_ILLEGAL = -608;

		public static final int CATEGORY_CID_NOEXSIT = -701;// 分类CID不存在
		public static final int CATEGORY_NAME_EXSIT = -702;// 分类名称已存在

		public static final int BRAND_BID_NOEXSIT = -801;
		public static final int BRAND_NAME_EXSIT = -802;

		public static final int CREDIT_RULE_ID_NOEXSIT = -901;
		public static final int CREDIT_EXEED_THRESHOLD = -902;
		public static final int CREDIT_THRESHOLD_ILLEGAL = -903;// 积分和阀值冲突，必须同正同负
		public static final int CREDIT_INS_HAVEADD = -904;// 

		public static final int BBSTHREAD_TITLE_ERROR = -1001;
		public static final int BBSTHREAD_LINK_ERROR = -1002;
		public static final int BBSTHREAD_ORDER_ERROR = -1003;
		public static final int BBSTHREAD_NULL_ERROR = -1004;

	}

	public static final List<Daren> darens = new ArrayList<Daren>() {
		private static final long serialVersionUID = -4521481357143405250L;
		{
			add(new Daren(1984618, "138xxxx3113p"));
			add(new Daren(554708, "ydsc5851585918c"));
			add(new Daren(48469, "sherryxu"));
			add(new Daren(161460, "lann"));
			add(new Daren(14371, "pallas"));
			add(new Daren(3408283, "151xxxx6396dm"));
			add(new Daren(241850, "蕙兰"));
			add(new Daren(155259, "jiaren"));
			add(new Daren(1803733, "158****37596"));
			add(new Daren(1452864, "幸福小猪"));
			// add(new Daren(4245295, "m65335108"));
			// add(new Daren(1984404, "Reeves"));
			// add(new Daren(2538475, "152xxxx7712n"));
		}
	};

	public static final DocConverter docConverter = DocConverter.getInstance();
	public static final DecompFile decompFile = DecompFile.getInstance();
}
