package instruction.rules;

import instruction.model.UserSession;

public interface UserSessionRule {
	public void setUserSession(UserSession userSession);
}
