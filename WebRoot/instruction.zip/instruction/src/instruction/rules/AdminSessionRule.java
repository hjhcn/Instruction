package instruction.rules;

import instruction.model.Admin;

public interface AdminSessionRule {
	public void setAdminSession(Admin admin);
}
