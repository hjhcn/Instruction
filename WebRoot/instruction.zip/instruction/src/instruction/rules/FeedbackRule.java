package instruction.rules;

public interface FeedbackRule {
	public void setFeedback(int feedback);
}
