package instruction.util;

import instruction.SystemConstants;
import instruction.model.User;
import instruction.model.UserSession;
import instruction.service.UserService;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.struts2.ServletActionContext;

public class CookieUtils {

	public Cookie addCookie(User user) {
		Cookie cookie = new Cookie(SystemConstants.USER_COOKIE, user.getUid()
				+ "");
		cookie.setPath("/");
		cookie.setMaxAge(60 * 60 * 24 * 14);// cookie保存两周
		return cookie;
	}

	public UserSession getUserSessionByCookie(UserService userService) {
		HttpServletRequest request = ServletActionContext.getRequest();
		Cookie[] cookies = request.getCookies();
		if (cookies != null) {
			for (Cookie cookie : cookies) {
				if (SystemConstants.USER_COOKIE.equals(cookie.getName())) {
					String value = cookie.getValue();
					if (StringUtils.isNotBlank(value)) {
						try {
							String ip = Ip.getIpAddr(request);
							User user = userService
									.get(Integer.parseInt(value));
							user.setLastip(ip);
							user.setLogintime(Time.getTimeStamp());
							UserSession userSession = new UserSession(user);
							userService.save(user);
							if (user != null) {
								HttpSession session = request.getSession();
								session.setAttribute(
										SystemConstants.USER_SESSION,
										userSession);
								return userSession;
							}
						} catch (Exception e) {
							// 转换异常
						}
					}
				}
			}
		}
		return null;
	}

	public Cookie delCookie() {
		HttpServletRequest request = ServletActionContext.getRequest();
		Cookie[] cookies = request.getCookies();
		if (cookies != null) {
			for (Cookie cookie : cookies) {
				if (SystemConstants.USER_COOKIE.equals(cookie.getName())) {
					cookie.setPath("/");
					cookie.setValue("");
					cookie.setMaxAge(0);
					return cookie;
				}
			}
		}
		return null;
	}
}
