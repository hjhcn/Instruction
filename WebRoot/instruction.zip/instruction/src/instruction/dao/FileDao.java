package instruction.dao;

import instruction.model.File;

public interface FileDao extends BaseDao<File> {
}
