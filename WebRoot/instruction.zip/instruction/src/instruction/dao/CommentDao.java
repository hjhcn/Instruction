package instruction.dao;

import instruction.model.Comment;

public interface CommentDao extends BaseDao<Comment> {

}
