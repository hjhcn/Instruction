package instruction.dao;

public interface NotiDao {

}
