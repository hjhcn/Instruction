package instruction.dao;

import instruction.model.BBSThread;

public interface BBSThreadDao  extends BaseDao<BBSThread> {

}
