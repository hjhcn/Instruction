package instruction.dao;

import instruction.model.User;

public interface UserDao extends BaseDao<User> {
	public void creditUpdate(int uid, int credit);
}
