package instruction.dao;

import instruction.model.Navigation;

public interface NaviDao extends BaseDao<Navigation> {

}
