package instruction.dao.impl;

import instruction.dao.CommentDao;
import instruction.model.Comment;

public class CommentDaoImpl extends BaseDaoImpl<Comment> implements
		CommentDao {
}
