package instruction.dao.impl;

import instruction.dao.NaviDao;
import instruction.model.Navigation;

public class NaviDaoImpl extends BaseDaoImpl<Navigation> implements NaviDao {

}
