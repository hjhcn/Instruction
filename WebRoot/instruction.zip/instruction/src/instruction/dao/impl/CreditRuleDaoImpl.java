package instruction.dao.impl;

import instruction.dao.CreditRuleDao;
import instruction.model.CreditRule;

public class CreditRuleDaoImpl extends BaseDaoImpl<CreditRule> implements
		CreditRuleDao {
}
