package instruction.dao.impl;

import instruction.dao.FileDao;
import instruction.model.File;

public class FileDaoImpl extends BaseDaoImpl<File> implements FileDao {

}
