package instruction.dao.impl;

import instruction.dao.BBSThreadDao;
import instruction.model.BBSThread;

public class BBSThreadDaoImpl  extends BaseDaoImpl<BBSThread> implements BBSThreadDao {

}
