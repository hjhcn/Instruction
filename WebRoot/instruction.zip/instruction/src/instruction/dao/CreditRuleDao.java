package instruction.dao;

import instruction.model.CreditRule;

public interface CreditRuleDao extends BaseDao<CreditRule> {

}
